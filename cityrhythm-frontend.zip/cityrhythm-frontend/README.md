# CityRhythm frontend

React + Vite + Leaflet dashboard. Runs on a built-in mock city, so it works with no backend.

## Run in VS Code
1. Install Node 20+ from nodejs.org.
2. File > Open Folder > `cityrhythm-frontend`.
3. Terminal > New Terminal, then:
   ```
   npm install
   npm run dev
   ```
4. Open http://localhost:5173. Press a scenario button on the left.

## Connect the real hub (R1)
In `.env` set `VITE_USE_MOCK=false` and `VITE_WS_URL=ws://localhost:8000/ws`.
It tries the hub for 2.5 s and falls back to the mock city if the hub is down.
Envelopes use the contract: `{v, channel, run_id, t, ts, zone, payload}`.
Channels handled: sim.tick, sync.index, sync.graph, sync.warning, baseline.alarm,
threat.assessment, threat.report_check, threat.redteam, fix.proposals, fix.plan,
fix.briefing, metrics.counterfactual, sim.scenario.

## Files
- `src/mock/MockCity.js`: mock emitter. Swap or extend scenarios here.
- `src/useCityStream.js`: WebSocket or mock, plus one reducer for every channel.
- `src/components/`: CityMap, Heartbeat, Sonifier, JudgePanel, SyncPanel, ThreatPanel, FixPanel, SplitScreen.
- `src/config.js`: status bands (70 / 40) and colours.

## Notes
- Map tiles need internet (CARTO dark + OpenStreetMap). Offline, the zone circles still draw on a dark background.
- Browsers block audio until a click, so use the "Hear the city" button.
- The numbers from the mock are illustrative. Real numbers must come from `RESULTS.md`.
