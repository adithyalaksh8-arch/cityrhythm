import { useEffect, useState } from 'react';
import { useCityStream } from './useCityStream';
import { computeLead } from './util';
import { ZONE_BY_ID } from './zones';
import CityMap from './components/CityMap';
import Heartbeat from './components/Heartbeat';
import Sonifier from './components/Sonifier';
import JudgePanel from './components/JudgePanel';
import SyncPanel from './components/SyncPanel';
import ThreatPanel from './components/ThreatPanel';
import FixPanel from './components/FixPanel';
import SplitScreen from './components/SplitScreen';

export default function App() {
  const { state, mode, send } = useCityStream();
  const [selected, setSelected] = useState('whitefield');
  const [layers, setLayers] = useState({ coupling: true, redteam: false });
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [auto, setAuto] = useState(false);

  useEffect(() => {
    if (state.scenario?.primary) setSelected(state.scenario.primary);
  }, [state.scenario?.id]);

  const minSync = Object.values(state.zones).reduce((m, z) => Math.min(m, z.sync_index), 100);
  const lead = computeLead(state);
  const warn = state.warnings[state.warnings.length - 1] ? state.warnings[0] : null;
  const alarmCount = Object.keys(state.alarms).length;

  return (
    <div className="app">
      <header className="top">
        <div>
          <h1>CityRhythm</h1>
          <p>Cities don’t crash. They lose their rhythm first.</p>
        </div>
        <div className="top-right">
          <span className="clock">{state.clock} IST</span>
          {state.temp != null && <span className="temp">{state.temp}°C</span>}
          <Sonifier minSync={minSync} />
          <span className={'mode mode-' + mode}>{mode === 'live' ? 'Live hub' : mode === 'mock' ? 'Mock city' : 'Connecting'}</span>
        </div>
      </header>

      <main className="grid">
        <aside className="col">
          <JudgePanel state={state} send={send} paused={paused} setPaused={setPaused} speed={speed} setSpeed={setSpeed} />
          <SyncPanel state={state} selected={selected} onSelect={setSelected} />
        </aside>

        <section className="col">
          <div className="card map-card">
            <div className="map-bar">
              <h2>Bengaluru zones <small>{ZONE_BY_ID[selected]?.name}</small></h2>
              <div className="row gap">
                <button className={'chip ' + (layers.coupling ? 'chip-on' : '')} onClick={() => setLayers((l) => ({ ...l, coupling: !l.coupling }))}>Learned couplings</button>
                <button className={'chip ' + (layers.redteam ? 'chip-on' : '')} onClick={() => setLayers((l) => ({ ...l, redteam: !l.redteam }))}>Weak spots</button>
              </div>
            </div>
            <div className="map-wrap">
              <CityMap state={state} selected={selected} onSelect={setSelected} layers={layers} />
              {state.scenario && (
                <div className={'banner ' + (lead ? 'banner-good' : warn ? 'banner-warn' : '')}>
                  <b>{state.scenario.label}</b>
                  <span>
                    {lead
                      ? `Warned ${lead.lead} min before the standard alarm`
                      : warn
                        ? alarmCount ? 'Standard alarm has fired' : 'Sync is dropping. Standard alarm still silent.'
                        : state.scenario.blurb}
                  </span>
                </div>
              )}
            </div>
          </div>
          <div className="card">
            <h2>Heartbeat <small>{ZONE_BY_ID[selected]?.name}</small></h2>
            <Heartbeat zone={state.zones[selected]} loads={state.loads[selected]} />
          </div>
        </section>

        <aside className="col">
          <ThreatPanel state={state} selected={selected} />
          <FixPanel state={state} send={send} auto={auto} setAuto={setAuto} />
          <SplitScreen state={state} />
        </aside>
      </main>
    </div>
  );
}
