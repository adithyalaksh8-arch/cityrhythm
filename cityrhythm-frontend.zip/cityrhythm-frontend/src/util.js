export const TAU = Math.PI * 2;
export const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));

export function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function fmtClock(m) {
  const mm = ((Math.round(m) % 1440) + 1440) % 1440;
  return String(Math.floor(mm / 60)).padStart(2, '0') + ':' + String(mm % 60).padStart(2, '0');
}

// Best "warned X min before the standard alarm" across zones.
export function computeLead(state) {
  let best = null;
  for (const w of state.warnings) {
    const a = state.alarms[w.zone];
    if (a != null) {
      const lead = a - w.t;
      if (!best || lead > best.lead) best = { zone: w.zone, lead };
    }
  }
  return best;
}
