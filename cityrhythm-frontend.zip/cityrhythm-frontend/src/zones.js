// Frozen zone ids from the contract. Coordinates are approximate zone centres.
export const ZONES = [
  { id: 'silk_board', name: 'Silk Board', short: 'Silk Board', lat: 12.9177, lng: 77.6238, r: 1700 },
  { id: 'whitefield', name: 'Whitefield', short: 'Whitefield', lat: 12.9698, lng: 77.75, r: 2400 },
  { id: 'hebbal', name: 'Hebbal', short: 'Hebbal', lat: 13.0358, lng: 77.597, r: 1900 },
  { id: 'electronic_city', name: 'Electronic City', short: 'E-City', lat: 12.8452, lng: 77.6602, r: 2200 },
  { id: 'koramangala', name: 'Koramangala', short: 'Koramangala', lat: 12.9352, lng: 77.6245, r: 1400 },
  { id: 'indiranagar', name: 'Indiranagar', short: 'Indiranagar', lat: 12.9784, lng: 77.6408, r: 1600 },
  { id: 'jayanagar', name: 'Jayanagar', short: 'Jayanagar', lat: 12.9308, lng: 77.5838, r: 1700 },
  { id: 'yelahanka', name: 'Yelahanka', short: 'Yelahanka', lat: 13.1007, lng: 77.5963, r: 2300 },
];
export const ZONE_BY_ID = Object.fromEntries(ZONES.map((z) => [z.id, z]));
