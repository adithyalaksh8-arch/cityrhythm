// Mirrors config/thresholds.json in the contract (healthy >= 70, drifting 40-69, critical < 40).
export const THRESHOLDS = { healthy: 70, drifting: 40 };

export const statusOf = (v) => (v >= THRESHOLDS.healthy ? 'healthy' : v >= THRESHOLDS.drifting ? 'drifting' : 'critical');

export const STATUS_COLOR = { healthy: '#4ef0c4', drifting: '#ffb454', critical: '#ff5470' };
export const SYSTEMS = ['traffic', 'power', 'water'];
export const SYSTEM_COLOR = { traffic: '#38d6ff', power: '#ffb454', water: '#9a8cff' };
