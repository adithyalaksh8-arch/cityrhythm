import { SCENARIOS } from '../mock/MockCity';

export default function JudgePanel({ state, send, paused, setPaused, speed, setSpeed }) {
  const active = state.scenario?.id;
  return (
    <section className="card">
      <h2>Trigger an event</h2>
      <div className="scen-list">
        {SCENARIOS.map((s) => (
          <button key={s.id} className={'scen ' + (active === s.id ? 'scen-on' : '')} onClick={() => send({ cmd: 'start_scenario', id: s.id })}>
            <span className="scen-glyph">{s.glyph}</span>
            <span><b>{s.label}</b><small>{s.blurb}</small></span>
          </button>
        ))}
      </div>
      <div className="row gap">
        <button className="chip" onClick={() => send({ cmd: 'reset' })}>Reset city</button>
        <button className="chip" onClick={() => { send({ cmd: 'pause', value: !paused }); setPaused(!paused); }}>{paused ? 'Resume' : 'Pause'}</button>
        <div className="seg">
          {[1, 5, 10].map((v) => (
            <button key={v} className={speed === v ? 'seg-on' : ''} onClick={() => { send({ cmd: 'set_speed', value: v }); setSpeed(v); }}>×{v}</button>
          ))}
        </div>
      </div>
    </section>
  );
}
