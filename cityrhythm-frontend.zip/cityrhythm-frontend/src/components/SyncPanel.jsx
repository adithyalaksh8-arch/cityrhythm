import { ZONES } from '../zones';
import { statusOf, STATUS_COLOR } from '../config';

function Spark({ data, color }) {
  const w = 92, h = 28;
  if (!data || data.length < 2) return <svg width={w} height={h} />;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - (v / 100) * h}`).join(' ');
  return <svg width={w} height={h}><polyline points={pts} fill="none" stroke={color} strokeWidth="1.6" strokeLinejoin="round" /></svg>;
}

export default function SyncPanel({ state, selected, onSelect }) {
  const sorted = [...ZONES];
  return (
    <section className="card">
      <h2>Sync index by zone</h2>
      <ul className="zones">
        {sorted.map((z) => {
          const zs = state.zones[z.id];
          const v = zs ? zs.sync_index : 96;
          const col = STATUS_COLOR[statusOf(v)];
          return (
            <li key={z.id} className={selected === z.id ? 'zone-on' : ''} onClick={() => onSelect(z.id)}>
              <span className="dot" style={{ background: col, boxShadow: `0 0 10px ${col}` }} />
              <span className="zname">{z.name}</span>
              <Spark data={state.hist[z.id]} color={col} />
              <b className="znum" style={{ color: col }}>{Math.round(v)}</b>
            </li>
          );
        })}
      </ul>
      <div className="legend">
        <span><i style={{ background: STATUS_COLOR.healthy }} />70 and above, healthy</span>
        <span><i style={{ background: STATUS_COLOR.drifting }} />40 to 69, drifting</span>
        <span><i style={{ background: STATUS_COLOR.critical }} />below 40, critical</span>
      </div>
    </section>
  );
}
