import { useEffect, useRef } from 'react';
import { SYSTEMS, SYSTEM_COLOR } from '../config';
import { TAU, clamp } from '../util';

const g = (u, c, a, w) => a * Math.exp(-((u - c) ** 2) / (2 * w * w));
function ecg(x) {
  const u = (((x / TAU) % 1) + 1) % 1;
  return g(u, 0.18, 0.12, 0.025) + g(u, 0.36, -0.15, 0.012) + g(u, 0.4, 1, 0.016) + g(u, 0.44, -0.25, 0.014) + g(u, 0.66, 0.3, 0.05);
}

export default function Heartbeat({ zone, loads }) {
  const canvases = useRef([]);
  const zr = useRef(zone);
  zr.current = zone;

  useEffect(() => {
    let raf, last = performance.now();
    const bufs = SYSTEMS.map(() => []);
    const acc = SYSTEMS.map(() => 0);
    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const z = zr.current;
      const dis = clamp(1 - (z ? z.sync_index : 96) / 100);
      const ph = z?.phases;
      SYSTEMS.forEach((s, i) => {
        const cv = canvases.current[i];
        if (!cv) return;
        const dpr = window.devicePixelRatio || 1;
        const W = cv.clientWidth, H = cv.clientHeight;
        if (cv.width !== W * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
        const ctx = cv.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const rel = ph ? ph[s] - ph.traffic : 0;
        for (let k = 0; k < 2; k++) {
          acc[i] += (dt / 2) * TAU * (1.15 + dis * 0.6 * Math.sin(now / 650 + i * 2));
          bufs[i].push(ecg(acc[i] + rel) + (Math.random() - 0.5) * dis * 0.35);
        }
        const step = 1.5, max = Math.ceil(W / step);
        if (bufs[i].length > max) bufs[i].splice(0, bufs[i].length - max);
        ctx.clearRect(0, 0, W, H);
        ctx.strokeStyle = 'rgba(140,160,255,.08)';
        ctx.beginPath(); ctx.moveTo(0, H * 0.72); ctx.lineTo(W, H * 0.72); ctx.stroke();
        ctx.strokeStyle = SYSTEM_COLOR[s];
        ctx.lineWidth = 1.8; ctx.lineJoin = 'round';
        ctx.shadowColor = SYSTEM_COLOR[s]; ctx.shadowBlur = 8;
        ctx.beginPath();
        const x0 = W - bufs[i].length * step;
        bufs[i].forEach((v, k) => { const x = x0 + k * step, y = H * 0.72 - v * H * 0.55; k ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
        ctx.stroke(); ctx.shadowBlur = 0;
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const R = 58;
  const ph = zone?.phases;
  const coh = zone?.phase_coherence ?? 1;
  let mx = 0, my = 0;
  if (ph) SYSTEMS.forEach((s) => { mx += Math.cos(ph[s]); my += Math.sin(ph[s]); });

  return (
    <div className="heart">
      <div className="ecgs">
        {SYSTEMS.map((s, i) => {
          const arr = loads?.[s];
          const v = arr ? arr[arr.length - 1] : null;
          return (
            <div className="ecg-row" key={s}>
              <div className="ecg-label"><span style={{ color: SYSTEM_COLOR[s] }}>{s}</span><b>{v == null ? '--' : Math.round(v * 100) + '%'}</b></div>
              <canvas ref={(e) => (canvases.current[i] = e)} />
            </div>
          );
        })}
      </div>
      <div className="wheel">
        <svg viewBox="-80 -80 160 160" width="170" height="170">
          <circle r={R} fill="none" stroke="rgba(140,160,255,.18)" />
          <circle r={R * 0.5} fill="none" stroke="rgba(140,160,255,.08)" />
          {ph && <line x1="0" y1="0" x2={(mx / 3) * R} y2={(my / 3) * R} stroke="#e8ecf8" strokeWidth="2" strokeLinecap="round" />}
          {ph && SYSTEMS.map((s) => <circle key={s} cx={Math.cos(ph[s]) * R} cy={Math.sin(ph[s]) * R} r="6" fill={SYSTEM_COLOR[s]} style={{ filter: `drop-shadow(0 0 5px ${SYSTEM_COLOR[s]})` }} />)}
          <text y="4" textAnchor="middle" className="wheel-num">{Math.round(coh * 100)}</text>
        </svg>
        <div className="wheel-cap">phase coherence</div>
      </div>
    </div>
  );
}
