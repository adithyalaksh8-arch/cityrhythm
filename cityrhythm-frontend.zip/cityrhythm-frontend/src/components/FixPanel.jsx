export default function FixPanel({ state, send, auto, setAuto }) {
  const b = state.briefing;
  return (
    <section className="card">
      <div className="row between">
        <h2>Mayor mode</h2>
        <label className="toggle">
          <input type="checkbox" checked={auto} onChange={(e) => { setAuto(e.target.checked); send({ cmd: 'set_auto', value: e.target.checked }); }} />
          <span>Auto-apply</span>
        </label>
      </div>
      {b ? (
        <ol className="brief">{b.summary.map((l, i) => <li key={i}>{l}</li>)}</ol>
      ) : <p className="empty">The briefing appears when a zone starts to drift.</p>}

      <h3>Cheapest fixes first</h3>
      <ul className="fixes">
        {state.proposals.map((p) => {
          const done = state.applied.includes(p.id);
          return (
            <li key={p.id}>
              <div>
                <b>{p.label}</b>
                <small>{p.dept} · peak overlap down {Math.round(p.peak_overlap_cut * 100)}%</small>
              </div>
              <button className={'chip ' + (done ? 'chip-on' : '')} disabled={done} onClick={() => send({ cmd: 'apply_fix', id: p.id })}>{done ? 'Applied' : 'Apply'}</button>
            </li>
          );
        })}
        {!state.proposals.length && <li className="empty">No active incident.</li>}
      </ul>
    </section>
  );
}
