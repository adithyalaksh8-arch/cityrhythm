const W = 300, H = 110, MAXT = 240;

function Curve({ data, color }) {
  if (!data || data.length < 2) return <svg viewBox={`0 0 ${W} ${H}`} className="curve" />;
  const pts = data.map((v, i) => [(i / MAXT) * W, H - v * (H - 10) - 4]);
  const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const last = pts[pts.length - 1];
  const area = `${line} L${last[0].toFixed(1)},${H} L0,${H} Z`;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="curve" preserveAspectRatio="none">
      <line x1="0" x2={W} y1={H - 0.8 * (H - 10) - 4} y2={H - 0.8 * (H - 10) - 4} stroke="rgba(255,255,255,.15)" strokeDasharray="3 4" />
      <path d={area} fill={color} opacity=".14" />
      <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
      <circle cx={last[0]} cy={last[1]} r="3.5" fill={color} />
    </svg>
  );
}

const rec = (v, never) => (v == null ? never : v === 0 ? 'never dipped' : v + ' min');

export default function SplitScreen({ state }) {
  const cf = state.cf;
  const no = cf?.no_action.resilience, wp = cf?.with_plan.resilience;
  const nowNo = no ? no[no.length - 1] : 1, nowWp = wp ? wp[wp.length - 1] : 1;
  return (
    <section className="card">
      <h2>Resilience score: act or wait</h2>
      <div className="split">
        <div className="half half-bad">
          <div className="half-head"><span>No action</span><b>{Math.round(nowNo * 100)}</b></div>
          <Curve data={no} color="#ff5470" />
          <small>Recovery: {cf ? rec(cf.recovery_min.no_action, 'not recovering') : '--'}</small>
        </div>
        <div className="half half-good">
          <div className="half-head"><span>CityRhythm</span><b>{Math.round(nowWp * 100)}</b></div>
          <Curve data={wp} color="#4ef0c4" />
          <small>Recovery: {cf ? rec(cf.recovery_min.with_plan, 'not recovering') : '--'}</small>
        </div>
      </div>
    </section>
  );
}
