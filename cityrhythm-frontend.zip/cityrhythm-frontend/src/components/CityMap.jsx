import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { ZONES, ZONE_BY_ID } from '../zones';
import { statusOf, STATUS_COLOR } from '../config';

export default function CityMap({ state, selected, onSelect, layers }) {
  const el = useRef(null);
  const map = useRef(null);
  const g = useRef({});
  const circles = useRef({});
  const pulses = useRef({});
  const heat = useRef({});
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  useEffect(() => {
    const m = L.map(el.current, { zoomControl: false, zoomSnap: 0.25 }).setView([12.98, 77.66], 11.25);
    L.control.zoom({ position: 'bottomleft' }).addTo(m);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19, attribution: '&copy; OpenStreetMap contributors',
}).addTo(m);
    g.current = { edges: L.layerGroup().addTo(m), heat: L.layerGroup().addTo(m), zones: L.layerGroup().addTo(m), pulse: L.layerGroup().addTo(m) };
    ZONES.forEach((z) => {
      const c = L.circle([z.lat, z.lng], { radius: z.r, color: '#4ef0c4', weight: 1.5, fillColor: '#4ef0c4', fillOpacity: 0.28 }).addTo(g.current.zones);
      c.bindTooltip('', { permanent: true, direction: 'center', className: 'zone-label' });
      c.on('click', () => onSelectRef.current(z.id));
      circles.current[z.id] = c;
      heat.current[z.id] = L.circle([z.lat, z.lng], { radius: z.r * 1.9, stroke: false, fillColor: '#ff5470', fillOpacity: 0, interactive: false }).addTo(g.current.heat);
    });
    map.current = m;
    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(el.current);
    setTimeout(() => m.invalidateSize(), 150);
    return () => { ro.disconnect(); m.remove(); };
  }, []);

  // coupling edges
  useEffect(() => {
    const lg = g.current.edges;
    if (!lg) return;
    lg.clearLayers();
    if (!layers.coupling) return;
    const seen = new Set();
    state.graph.forEach((e) => {
      const a = e.src.split('.')[0], b = e.dst.split('.')[0];
      if (a === b || seen.has(a + '>' + b)) return;
      seen.add(a + '>' + b);
      const za = ZONE_BY_ID[a], zb = ZONE_BY_ID[b];
      L.polyline([[za.lat, za.lng], [zb.lat, zb.lng]], { color: '#9a8cff', weight: 1 + e.strength * 3, opacity: 0.8, className: 'edge' })
        .bindTooltip(`${e.src} → ${e.dst} · ${e.lag_min} min lag`, { sticky: true })
        .addTo(lg);
    });
  }, [state.graph, layers.coupling]);

  // red-team heat
  useEffect(() => {
    const vul = {};
    state.redteam.forEach((n) => { const z = n.node.split('.')[0]; vul[z] = Math.max(vul[z] || 0, n.score); });
    ZONES.forEach((z) => heat.current[z.id]?.setStyle({ fillOpacity: layers.redteam ? (vul[z.id] || 0) * 0.32 : 0 }));
  }, [state.redteam, layers.redteam]);

  // zone colours, labels, attack pulses
  useEffect(() => {
    ZONES.forEach((z) => {
      const c = circles.current[z.id];
      if (!c) return;
      const zs = state.zones[z.id];
      const v = zs ? zs.sync_index : 96;
      const col = STATUS_COLOR[statusOf(v)];
      const sel = selected === z.id;
      c.setStyle({ color: sel ? '#ffffff' : col, fillColor: col, weight: sel ? 3 : 1.5, fillOpacity: sel ? 0.42 : 0.3 });
      c.setTooltipContent(`<div>${z.short}</div><div class="zl-num">${Math.round(v)}</div>`);

      const attack = state.threat[z.id]?.label === 'attack';
      if (attack && !pulses.current[z.id]) {
        pulses.current[z.id] = L.marker([z.lat, z.lng], {
          interactive: false,
          icon: L.divIcon({ className: '', html: '<div class="pulse"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }),
        }).addTo(g.current.pulse);
      } else if (!attack && pulses.current[z.id]) {
        g.current.pulse.removeLayer(pulses.current[z.id]);
        delete pulses.current[z.id];
      }
    });
  }, [state.zones, state.threat, selected]);

  return <div ref={el} className="map" />;
}
