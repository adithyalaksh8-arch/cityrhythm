import { useEffect, useRef, useState } from 'react';
import { clamp } from '../util';

// Harmonious A-major triad when the city is in sync; detuned and tremolo-ed as sync is lost.
export default function Sonifier({ minSync }) {
  const [on, setOn] = useState(false);
  const a = useRef(null);

  const start = () => {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    const master = ac.createGain();
    master.gain.value = 0;
    master.connect(ac.destination);
    const oscs = [220, 277.18, 329.63].map((f, i) => {
      const o = ac.createOscillator();
      o.type = i === 0 ? 'sine' : 'triangle';
      o.frequency.value = f;
      const gn = ac.createGain(); gn.gain.value = 0.33;
      o.connect(gn); gn.connect(master); o.start();
      return o;
    });
    const lfo = ac.createOscillator(); lfo.frequency.value = 2;
    const lg = ac.createGain(); lg.gain.value = 0;
    lfo.connect(lg); lg.connect(master.gain); lfo.start();
    master.gain.setTargetAtTime(0.06, ac.currentTime, 0.4);
    a.current = { ac, master, oscs, lfo, lg };
    setOn(true);
  };
  const stop = () => {
    const x = a.current;
    if (x) { x.master.gain.setTargetAtTime(0, x.ac.currentTime, 0.15); setTimeout(() => x.ac.close(), 500); }
    a.current = null;
    setOn(false);
  };

  useEffect(() => {
    const x = a.current;
    if (!x) return;
    const dis = clamp((100 - minSync) / 70);
    const t = x.ac.currentTime;
    x.oscs[1].detune.setTargetAtTime(-130 * dis, t, 0.3);
    x.oscs[2].detune.setTargetAtTime(95 * dis, t, 0.3);
    x.lfo.frequency.setTargetAtTime(2 + dis * 7, t, 0.3);
    x.lg.gain.setTargetAtTime(0.045 * dis, t, 0.3);
  }, [minSync, on]);

  useEffect(() => () => a.current?.ac.close(), []);

  return (
    <button className={'chip ' + (on ? 'chip-on' : '')} onClick={on ? stop : start} title="Hear the city">
      {on ? 'Sound on' : 'Hear the city'}
    </button>
  );
}
