import { ZONE_BY_ID } from '../zones';

const LABEL = { natural: 'Natural event', attack: 'Likely attack', unknown: 'Unknown' };

export default function ThreatPanel({ state, selected }) {
  const th = state.threat[selected];
  const zname = ZONE_BY_ID[selected]?.name;
  return (
    <section className="card">
      <h2>Nature or attacker? <small>{zname}</small></h2>
      {th ? (
        <>
          <div className="row between">
            <span className={'badge badge-' + th.label}>{LABEL[th.label]}</span>
            <span className="conf">{Math.round(th.confidence * 100)}% sure</span>
          </div>
          <div className="bar"><i style={{ width: th.confidence * 100 + '%' }} className={'fill-' + th.label} /></div>
          {th.entry_node && <p className="entry">Suspected entry point: <b>{th.entry_node}</b></p>}
          <ul className="evidence">
            {th.evidence.map((e, i) => (
              <li key={i}><span>{e.detail}</span><em>{Math.round(e.score * 100)}</em></li>
            ))}
          </ul>
        </>
      ) : <p className="empty">Nothing suspicious in this zone. Trigger an event to see a verdict.</p>}

      <h3>Citizen reports <small>synthetic</small></h3>
      <ul className="reports">
        {state.reports.slice(0, 6).map((r) => (
          <li key={r.id}>
            <span className={'chip-v ' + (r.verified ? 'v-yes' : 'v-no')}>{r.verified ? 'Backed by sensors' : 'No sensor agrees'}</span>
            <span className="rtext">{r.text}</span>
          </li>
        ))}
        {!state.reports.length && <li className="empty">No reports yet.</li>}
      </ul>
    </section>
  );
}
