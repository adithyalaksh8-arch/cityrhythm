import { useEffect, useReducer, useState, useRef, useCallback } from 'react';
import { MockCity } from './mock/MockCity';

const USE_MOCK = (import.meta.env.VITE_USE_MOCK ?? 'true') !== 'false';
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws';

const init = () => ({
  t: 0, clock: '--:--', scenario: null, temp: null,
  zones: {}, hist: {}, loads: {}, graph: [], threat: {}, reports: [],
  warnings: [], alarms: {}, proposals: [], applied: [], briefing: null, cf: null, redteam: [],
});

function apply(s, e) {
  const p = e.payload;
  switch (e.channel) {
    case 'sim.tick': {
      const loads = { ...s.loads };
      for (const r of p.readings) {
        const zl = (loads[r.zone] = { ...(loads[r.zone] || {}) });
        zl[r.system] = [...(zl[r.system] || []).slice(-159), r.value];
      }
      return { ...s, t: e.t, clock: p.context?.clock ?? s.clock, temp: p.context?.temp_c ?? s.temp, loads };
    }
    case 'sync.index':
      return { ...s, zones: { ...s.zones, [p.zone]: p }, hist: { ...s.hist, [p.zone]: [...(s.hist[p.zone] || []).slice(-119), p.sync_index] } };
    case 'sync.graph': return { ...s, graph: p.edges };
    case 'sync.warning': return { ...s, warnings: [{ ...p, t: e.t }, ...s.warnings].slice(0, 8) };
    case 'baseline.alarm': return { ...s, alarms: { ...s.alarms, [p.zone]: e.t } };
    case 'threat.assessment': return { ...s, threat: { ...s.threat, [p.zone]: p } };
    case 'threat.report_check': return { ...s, reports: [p, ...s.reports].slice(0, 40) };
    case 'threat.redteam': return { ...s, redteam: p.nodes };
    case 'fix.proposals': return { ...s, proposals: p.actions, applied: [] };
    case 'fix.plan': return { ...s, applied: p.applied };
    case 'fix.briefing': return { ...s, briefing: p };
    case 'metrics.counterfactual': return { ...s, cf: p };
    case 'sim.scenario':
      return { ...s, scenario: p.id ? p : null, warnings: [], alarms: {}, threat: {}, reports: [], briefing: null, cf: null, proposals: [], applied: [], hist: {}, redteam: [] };
    default: return s;
  }
}

function reducer(state, action) {
  if (action.type !== 'batch') return state;
  let s = state;
  for (const e of action.envs) s = apply(s, e);
  return s;
}

export function useCityStream() {
  const [state, dispatch] = useReducer(reducer, undefined, init);
  const [mode, setMode] = useState(USE_MOCK ? 'mock' : 'connecting');
  const engine = useRef(null);
  const ws = useRef(null);

  useEffect(() => {
    let cancelled = false;
    const startMock = () => {
      if (engine.current || cancelled) return;
      engine.current = new MockCity((envs) => dispatch({ type: 'batch', envs }));
      setMode('mock');
      engine.current.start();
    };
    if (USE_MOCK) startMock();
    else {
      const sock = new WebSocket(WS_URL);
      ws.current = sock;
      const timeout = setTimeout(() => { if (sock.readyState !== 1) { sock.close(); startMock(); } }, 2500);
      sock.onopen = () => { clearTimeout(timeout); setMode('live'); };
      sock.onmessage = (ev) => { try { dispatch({ type: 'batch', envs: [JSON.parse(ev.data)] }); } catch { /* ignore bad frame */ } };
      sock.onclose = () => { if (!cancelled && !engine.current) startMock(); };
    }
    return () => { cancelled = true; engine.current?.destroy(); engine.current = null; ws.current?.close(); };
  }, []);

  const send = useCallback((cmd) => {
    if (engine.current) engine.current.handle(cmd);
    else if (ws.current?.readyState === 1) ws.current.send(JSON.stringify(cmd));
  }, []);

  return { state, mode, send };
}
