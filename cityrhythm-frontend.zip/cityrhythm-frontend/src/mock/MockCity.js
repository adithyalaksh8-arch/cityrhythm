// Mock city: emits the same envelopes the real hub will send (see the integration contract).
// Replace with the real WebSocket by setting VITE_USE_MOCK=false.
import { ZONES, ZONE_BY_ID } from '../zones';
import { clamp, rng, TAU, fmtClock } from '../util';
import { statusOf, SYSTEMS } from '../config';

export const SCENARIOS = [
  { id: 'heatwave', label: 'Heatwave', glyph: '☀', blurb: 'Slow burn. Every dashboard stays green.', primary: 'whitefield', tod: 900 },
  { id: 'match_end_9pm', label: 'Match ends at 9 PM', glyph: '◔', blurb: 'Crowd surge ripples from traffic to power.', primary: 'indiranagar', tod: 1230 },
  { id: 'signal_hijack', label: 'Signal hijack', glyph: '⌁', blurb: 'Spoofed signal controller at Silk Board.', primary: 'silk_board', tod: 1080 },
  { id: 'replay_attack', label: 'Replay attack', glyph: '↻', blurb: 'A looped feed that fools threshold alarms.', primary: 'hebbal', tod: 840 },
  { id: 'fake_panic', label: 'Fake-panic campaign', glyph: '☊', blurb: 'Coordinated fake “no power” reports.', primary: 'jayanagar', tod: 1140 },
];

const ALARM = 0.8; // the naive threshold alarm
const HEAT = { whitefield: 1, electronic_city: 0.95, silk_board: 0.88, koramangala: 0.7, indiranagar: 0.62, hebbal: 0.5, jayanagar: 0.42, yelahanka: 0.34 };

function baseSev(sc, z, dt) {
  switch (sc) {
    case 'heatwave':
      return clamp((dt - 15) / 170) * (HEAT[z] ?? 0.3);
    case 'match_end_9pm': {
      const w = { indiranagar: 1, koramangala: 0.8, silk_board: 0.5 }[z];
      if (!w) return 0;
      return w * Math.pow(Math.sin(Math.PI * clamp((dt - 15) / 110)), 1.4);
    }
    case 'signal_hijack':
      if (z === 'silk_board') return clamp((dt - 12) / 14) * 0.92;
      if (z === 'electronic_city') return clamp((dt - 30) / 50) * 0.6;
      if (z === 'koramangala') return clamp((dt - 30) / 50) * 0.45;
      return 0;
    case 'replay_attack':
      return z === 'hebbal' ? clamp((dt - 10) / 20) * 0.55 : 0;
    default:
      return 0;
  }
}

const SYSW = {
  heatwave: { traffic: 0.3, power: 1, water: 0.9 },
  match_end_9pm: { traffic: 1, power: 0.7, water: 0.3 },
  signal_hijack: { traffic: 1, power: 0.8, water: 0.2 },
  replay_attack: { traffic: 0, power: 0, water: 0 },
  fake_panic: { traffic: 0, power: 0, water: 0 },
};

const TPL = {
  power: [['en', 'No power in {z} for 20 mins!!'], ['kn', '{z} ನಲ್ಲಿ ಕರೆಂಟ್ ಇಲ್ಲ, 30 ನಿಮಿಷ ಆಯ್ತು'], ['hi', '{z} mein light nahi hai yaar, kab aayegi?']],
  water: [['en', 'Water pressure very low in {z}'], ['kn', '{z} ನಲ್ಲಿ ನೀರಿನ ಒತ್ತಡ ಕಡಿಮೆ ಇದೆ'], ['hi', '{z} mein paani ka pressure bahut low hai']],
  traffic: [['en', 'Stuck at {z} for 40 min, not moving'], ['kn', '{z} ಹತ್ತಿರ ಟ್ರಾಫಿಕ್ ಜಾಮ್, ಮುಂದೆ ಹೋಗ್ತಿಲ್ಲ'], ['hi', '{z} pe traffic bilkul jam hai']],
};

const GRAPH = [
  { src: 'silk_board.traffic', dst: 'silk_board.power', lag_min: 12, strength: 0.82 },
  { src: 'silk_board.traffic', dst: 'electronic_city.power', lag_min: 18, strength: 0.61 },
  { src: 'whitefield.power', dst: 'whitefield.water', lag_min: 9, strength: 0.7 },
  { src: 'koramangala.traffic', dst: 'indiranagar.traffic', lag_min: 7, strength: 0.66 },
  { src: 'hebbal.traffic', dst: 'yelahanka.power', lag_min: 15, strength: 0.5 },
  { src: 'indiranagar.traffic', dst: 'whitefield.power', lag_min: 11, strength: 0.44 },
  { src: 'jayanagar.water', dst: 'koramangala.power', lag_min: 14, strength: 0.38 },
  { src: 'koramangala.power', dst: 'silk_board.water', lag_min: 10, strength: 0.52 },
];

const REDTEAM = [
  { node: 'silk_board.traffic', score: 0.94, cost: 0.2 },
  { node: 'whitefield.power', score: 0.81, cost: 0.4 },
  { node: 'electronic_city.power', score: 0.74, cost: 0.45 },
  { node: 'koramangala.power', score: 0.58, cost: 0.5 },
  { node: 'hebbal.traffic', score: 0.46, cost: 0.35 },
  { node: 'indiranagar.traffic', score: 0.41, cost: 0.3 },
];

const PROPOSALS = {
  heatwave: [
    { id: 'a1', type: 'shift_pump', dept: 'water', zone: 'whitefield', label: 'Stagger pump schedules by 40 min', peak_overlap_cut: 0.31 },
    { id: 'a2', type: 'shift_schedule', dept: 'power', zone: 'whitefield', label: 'Stagger IT-park AC pre-cooling', peak_overlap_cut: 0.22 },
    { id: 'a3', type: 'offset_signal', dept: 'traffic', zone: 'electronic_city', label: 'Offset green-waves on Hosur Road', peak_overlap_cut: 0.12 },
  ],
  match_end_9pm: [
    { id: 'a1', type: 'offset_signal', dept: 'traffic', zone: 'indiranagar', label: 'Hold 100 Feet Rd green-wave for 12 min', peak_overlap_cut: 0.28 },
    { id: 'a2', type: 'shift_schedule', dept: 'power', zone: 'koramangala', label: 'Pre-charge feeder reserve before 9 PM', peak_overlap_cut: 0.19 },
    { id: 'a3', type: 'reroute', dept: 'traffic', zone: 'silk_board', label: 'Divert ORR traffic via Sarjapur Rd', peak_overlap_cut: 0.11 },
  ],
  signal_hijack: [
    { id: 'a1', type: 'offset_signal', dept: 'traffic', zone: 'silk_board', label: 'Isolate controller, switch to fixed-time plan', peak_overlap_cut: 0.4 },
    { id: 'a2', type: 'shed_load', dept: 'power', zone: 'electronic_city', label: 'Pre-shed 8% of feeder load', peak_overlap_cut: 0.2 },
    { id: 'a3', type: 'reroute', dept: 'traffic', zone: 'koramangala', label: 'Reroute via inner roads', peak_overlap_cut: 0.1 },
  ],
  replay_attack: [
    { id: 'a1', type: 'shed_load', dept: 'power', zone: 'hebbal', label: 'Quarantine feed, use redundant meter', peak_overlap_cut: 0.35 },
    { id: 'a2', type: 'shift_schedule', dept: 'power', zone: 'hebbal', label: 'Re-key telemetry gateway', peak_overlap_cut: 0.2 },
    { id: 'a3', type: 'shift_schedule', dept: 'power', zone: 'yelahanka', label: 'Cross-check neighbouring feeders', peak_overlap_cut: 0.1 },
  ],
  fake_panic: [
    { id: 'a1', type: 'shift_schedule', dept: 'power', zone: 'jayanagar', label: 'Publish a verified “grid normal” advisory', peak_overlap_cut: 0.3 },
    { id: 'a2', type: 'shift_schedule', dept: 'power', zone: 'jayanagar', label: 'Rate-limit duplicate report sources', peak_overlap_cut: 0.2 },
    { id: 'a3', type: 'shift_schedule', dept: 'power', zone: 'jayanagar', label: 'Hand the report cluster to the cyber cell', peak_overlap_cut: 0.1 },
  ],
};

const BRIEF = {
  heatwave: ['Power and water are drifting apart in Whitefield while every dashboard is green.', 'Overload is likely within about an hour if nothing changes.', 'Shift timing now, because it is cheaper than adding capacity later.'],
  match_end_9pm: ['A crowd surge is moving from traffic into power around Indiranagar.', 'This looks like natural demand, not an attack.', 'Hold the green-wave and pre-charge reserve before 9 PM.'],
  signal_hijack: ['Silk Board signals are out of step with their neighbours with no real cause.', 'This looks like an attack at silk_board.traffic, and power stress follows about 12 min later.', 'Isolate the controller first, then protect the feeder.'],
  replay_attack: ['Hebbal power readings repeat a 90 min loop almost perfectly.', 'Threshold alarms are silent, but this feed is replayed data.', 'Quarantine the feed and switch to the redundant meter.'],
  fake_panic: ['Many “no power” reports in Jayanagar, but no feeder sensor agrees.', 'This looks like a coordinated fake-report campaign.', 'Publish a verified status and flag the report cluster.'],
};

export class MockCity {
  constructor(emit) {
    this.emit = emit;
    this.runId = 'r_01';
    this.rand = rng(7);
    this.speed = 1;
    this.paused = false;
    this.auto = false;
    this.t = 0;
    this.timer = null;
    this.resetState();
  }

  resetState() {
    this.scen = null;
    this.t0 = this.t;
    this.tod = 1020;
    this.fix = 1;
    this.fixAt = null;
    this.tau = 30;
    this.applied = new Set();
    this.warned = new Set();
    this.alarmed = new Set();
    this.briefed = false;
    this.cfNo = [];
    this.cfWith = [];
    this.idx = Object.fromEntries(ZONES.map((z) => [z.id, 96]));
    this.repN = 0;
  }

  env(channel, payload, zone = null) {
    return { v: 1, channel, run_id: this.runId, t: this.t, ts: `2026-11-17T${fmtClock(this.tod)}:00+05:30`, zone, payload };
  }

  start() {
    this.emit([this.env('sim.scenario', { id: null }), this.env('sync.graph', { edges: GRAPH }), this.env('system.status', { mode: 'mock' })]);
    this.restartTimer();
  }
  restartTimer() {
    clearInterval(this.timer);
    this.timer = setInterval(() => this.tick(), 1000 / this.speed);
  }
  destroy() {
    clearInterval(this.timer);
  }

  handle(c) {
    switch (c.cmd) {
      case 'start_scenario': return this.startScenario(c.id);
      case 'reset': this.resetState(); return this.emit([this.env('sim.scenario', { id: null }), this.env('sync.graph', { edges: GRAPH })]);
      case 'apply_fix': return this.applyFix(c.id);
      case 'apply_all': return (PROPOSALS[this.scen?.id] || []).forEach((p) => this.applyFix(p.id));
      case 'set_speed': this.speed = c.value; return this.restartTimer();
      case 'pause': this.paused = c.value; return;
      case 'set_auto': this.auto = c.value; return;
      default:
    }
  }

  startScenario(id) {
    const sc = SCENARIOS.find((s) => s.id === id);
    if (!sc) return;
    this.resetState();
    this.scen = sc;
    this.t0 = this.t;
    this.tod = sc.tod;
    this.emit([
      this.env('sim.scenario', { id: sc.id, label: sc.label, blurb: sc.blurb, primary: sc.primary }),
      this.env('sync.graph', { edges: GRAPH }),
      this.env('threat.redteam', { nodes: REDTEAM }),
      this.env('fix.proposals', { actions: PROPOSALS[sc.id] }),
    ]);
  }

  applyFix(id) {
    if (!this.scen || this.applied.has(id)) return;
    this.applied.add(id);
    const dt = this.t - this.t0;
    if (this.fixAt == null) this.fixAt = dt;
    this.tau = 34 / (1 + this.applied.size * 0.7);
    this.emit([this.env('fix.plan', { applied: [...this.applied], start_t: this.fixAt })]);
  }

  threat(id, z, dt, sev) {
    if (id === 'heatwave' || id === 'match_end_9pm') {
      if (sev < 0.2) return null;
      return {
        zone: z, label: 'natural', confidence: clamp(0.7 + sev * 0.25), entry_node: null,
        evidence: [
          { kind: 'physics_consistency', detail: id === 'heatwave' ? 'Temperature up, so power and water demand rise together' : 'Crowd surge moves from traffic to power in the expected order', score: 0.92 },
          { kind: 'sensor_trust', detail: 'Sensors agree with their neighbours (trust 0.96)', score: 0.96 },
        ],
      };
    }
    if (id === 'signal_hijack') {
      if (z === 'silk_board' && dt > 14) {
        return {
          zone: z, label: 'attack', confidence: clamp(0.5 + (dt - 14) * 0.035, 0, 0.95), entry_node: 'silk_board.traffic',
          evidence: [
            { kind: 'physics_violation', detail: 'Jam with no cause: no event, no rain, neighbours flowing', score: 0.9 },
            { kind: 'phase_mismatch', detail: 'Signal cycle is about 150° out of phase with its neighbours', score: 0.84 },
            { kind: 'lag_pattern', detail: 'Power stress follows 12 min later, as in a cascade', score: 0.71 },
          ],
        };
      }
      if (sev > 0.2) return { zone: z, label: 'unknown', confidence: 0.55, entry_node: null, evidence: [{ kind: 'downstream', detail: 'Stress looks downstream of silk_board.traffic', score: 0.6 }] };
    }
    if (id === 'replay_attack' && z === 'hebbal' && dt > 25) {
      return {
        zone: z, label: 'attack', confidence: clamp(0.6 + (dt - 25) * 0.02, 0, 0.96), entry_node: 'hebbal.power',
        evidence: [
          { kind: 'replay', detail: 'Autocorrelation 0.998 at a 90 min loop period', score: 0.98 },
          { kind: 'segment_hash', detail: 'Repeated segments match exactly, so real noise is missing', score: 0.93 },
          { kind: 'threshold_alarm', detail: 'Standard alarms are silent, loads look normal', score: 0.5 },
        ],
      };
    }
    if (id === 'fake_panic' && z === 'jayanagar' && dt > 12) {
      return {
        zone: z, label: 'attack', confidence: clamp(0.55 + (dt - 12) * 0.015, 0, 0.9), entry_node: null,
        evidence: [
          { kind: 'report_sensor_agreement', detail: `${Math.min(60, (dt - 12) * 2)} “no power” reports, 0 of 6 feeder sensors agree`, score: 0.95 },
          { kind: 'burst_pattern', detail: 'Near-identical phrasing from new accounts', score: 0.82 },
        ],
      };
    }
    return null;
  }

  tick() {
    if (this.paused) return;
    this.t += 1;
    this.tod = (this.tod + 1) % 1440;
    const sc = this.scen;
    const id = sc?.id;
    const dt = sc ? this.t - this.t0 : 0;
    if (this.fixAt != null) this.fix *= Math.exp(-1 / this.tau);

    const out = [];
    const readings = [];
    let primarySevBase = 0, primarySev = 0;

    for (const z of ZONES) {
      const base = sc ? baseSev(id, z.id, dt) : 0;
      const sev = base * this.fix;
      if (sc && z.id === sc.primary) { primarySevBase = base; primarySev = sev; }
      const n = () => (this.rand() - 0.5);
      const isReplay = id === 'replay_attack' && z.id === 'hebbal' && dt > 10;

      const off = { traffic: n() * 0.05, power: 1.9 * sev + n() * 0.05, water: -1.6 * sev + n() * 0.05 };
      if (id === 'signal_hijack' && z.id === 'silk_board') off.traffic = Math.PI * 0.85 * sev;
      const phases = Object.fromEntries(SYSTEMS.map((s) => [s, ((((TAU * this.tod) / 1440 + off[s]) % TAU) + TAU) % TAU]));
      let cx = 0, cy = 0;
      SYSTEMS.forEach((s) => { cx += Math.cos(phases[s]); cy += Math.sin(phases[s]); });
      let coh = Math.hypot(cx, cy) / 3;
      let csd = clamp(sev * 0.95 + n() * 0.04);
      let cb = clamp(sev * 0.85 + n() * 0.04);
      if (isReplay) {
        const ramp = clamp((dt - 10) / 20) * this.fix;
        coh = 0.97 - 0.17 * ramp; csd = 0.04; cb = 0.85 * ramp;
      }
      const target = 100 * clamp(0.5 * coh + 0.25 * (1 - csd) + 0.25 * (1 - cb));
      this.idx[z.id] = this.idx[z.id] * 0.75 + target * 0.25;
      const si = this.idx[z.id];

      const w = SYSW[id] || { traffic: 0, power: 0, water: 0 };
      let maxLoad = 0;
      for (const s of SYSTEMS) {
        const ph = phases[s];
        let v = 0.48 + 0.17 * Math.sin(ph - 3.665) + 0.38 * Math.pow(sev, 2.2) * (w[s] ?? 0) + n() * 0.03;
        if (isReplay && s === 'power') v = 0.48 + 0.17 * Math.sin(TAU * ((this.tod % 90) / 90));
        v = clamp(v, 0, 1);
        maxLoad = Math.max(maxLoad, v);
        readings.push({ zone: z.id, system: s, metric: 'load', value: +v.toFixed(3), raw: +(v * 100).toFixed(1), unit: 'norm', sensor_id: `${z.id}.${s}.01` });
      }

      out.push(this.env('sync.index', {
        zone: z.id, sync_index: +si.toFixed(1), status: statusOf(si),
        phase_coherence: +coh.toFixed(3), csd_score: +csd.toFixed(3), coupling_break: +cb.toFixed(3),
        phases: Object.fromEntries(SYSTEMS.map((s) => [s, +phases[s].toFixed(3)])),
      }, z.id));

      if (sc && si < 70 && !this.warned.has(z.id)) {
        this.warned.add(z.id);
        out.push(this.env('sync.warning', { zone: z.id, sync_index: +si.toFixed(1), message: `${ZONE_BY_ID[z.id].name} is drifting out of sync` }, z.id));
        if (!this.briefed) {
          this.briefed = true;
          out.push(this.env('fix.briefing', { summary: BRIEF[id], actions: PROPOSALS[id].map((p) => p.label) }));
          if (this.auto && this.fixAt == null) PROPOSALS[id].forEach((p) => this.applyFix(p.id));
        }
      }
      if (sc && maxLoad > ALARM && !this.alarmed.has(z.id) && id !== 'replay_attack' && id !== 'fake_panic') {
        this.alarmed.add(z.id);
        out.push(this.env('baseline.alarm', { zone: z.id, message: 'Threshold alarm fired' }, z.id));
      }

      if (sc && this.t % 3 === 0) {
        const th = this.threat(id, z.id, dt, sev);
        if (th) out.push(this.env('threat.assessment', th, z.id));
      }

      if (sc && id !== 'fake_panic' && sev > 0.4 && this.t % 7 === 0) {
        const sys = id === 'match_end_9pm' ? 'traffic' : this.rand() < 0.5 ? 'power' : 'water';
        const [lang, txt] = TPL[sys][Math.floor(this.rand() * 3)];
        out.push(this.env('threat.report_check', { id: `rp_${++this.repN}`, zone: z.id, text: txt.replace('{z}', z.name), lang, source: 'synthetic', verified: sev > 0.5 }, z.id));
      }
    }

    if (id === 'fake_panic' && dt >= 12 && dt <= 75) {
      const [lang, txt] = TPL.power[Math.floor(this.rand() * 3)];
      out.push(this.env('threat.report_check', { id: `rp_${++this.repN}`, zone: 'jayanagar', text: txt.replace('{z}', 'Jayanagar'), lang, source: 'synthetic', verified: false }, 'jayanagar'));
      if (dt >= 18 && !this.briefed) {
        this.briefed = true;
        out.push(this.env('sync.warning', { zone: 'jayanagar', sync_index: 90, message: 'Report burst with no sensor support' }, 'jayanagar'));
        out.push(this.env('fix.briefing', { summary: BRIEF[id], actions: PROPOSALS[id].map((p) => p.label) }));
        if (this.auto) PROPOSALS[id].forEach((p) => this.applyFix(p.id));
      }
    }

    if (sc) {
      this.cfNo.push(+(1 - 0.85 * primarySevBase).toFixed(3));
      this.cfWith.push(+(1 - 0.85 * primarySev).toFixed(3));
      if (this.t % 3 === 0) {
        out.push(this.env('metrics.counterfactual', {
          t: this.cfNo.map((_, i) => i),
          no_action: { resilience: [...this.cfNo] },
          with_plan: { resilience: [...this.cfWith] },
          recovery_min: { no_action: recovery(this.cfNo), with_plan: recovery(this.cfWith) },
        }));
      }
    }

    out.unshift(this.env('sim.tick', {
      readings,
      context: { temp_c: +(30 + 5 * Math.sin((TAU * (this.tod - 600)) / 1440) + (id === 'heatwave' ? 6 * clamp(dt / 150) : 0)).toFixed(1), events: id === 'match_end_9pm' ? ['match_end'] : [], is_holiday: false, clock: fmtClock(this.tod) },
      reports: [],
    }));
    this.emit(out);
  }
}

// minutes from first dip below 0.8 until it climbs back; null if it never recovers
function recovery(arr) {
  const i = arr.findIndex((v) => v < 0.8);
  if (i < 0) return 0;
  const j = arr.findIndex((v, k) => k > i && v >= 0.8);
  return j < 0 ? null : j - i;
}
